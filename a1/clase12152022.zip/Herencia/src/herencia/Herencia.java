package herencia;

public class Herencia {
    
    public static void main(String[] args) {
        int a=10,b=20,c=30;
        Punto2 p=new Punto2(a,b,c);
        System.out.println("Objeto creado");
        System.out.println(p.x+" "+p.y+" "+p.z);
    }
    
}
