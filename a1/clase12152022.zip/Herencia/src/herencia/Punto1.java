/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

public class Punto1 {
    int x,y;
    Punto1 (int a, int b){
        this.x=a;
        this.y=b;
    }
}
